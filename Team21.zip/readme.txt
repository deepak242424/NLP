1. To Run Word Spell Checker
$: python sentencespellcheck.py <test-file>
Output in file "<test-file>WSC"

2. To Run Phrase Spell Checker
$: python phrasepellcheck.py <test-file>
Output in file "<test-file>PSC"

3. To Run Sentence Spell Checker
$: python sentencespellcheck.py <test-file>
Output in file "<test-file>SSC"




